
package com.tecniva.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.webView);
        FloatingActionButton fab = findViewById(R.id.fabWhatsApp);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://tecniva.co.tz");

        fab.setOnClickListener(v -> {
            String phone = "255719977592";
            String msg = "Habari, nahitaji huduma kutoka TECNIVA";
            startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/" + phone + "?text=" + Uri.encode(msg))));
        });
    }
}
